function ContasDAO(connection){
    this._connection = connection;
}
ContasDAO.prototype.lista = function(callback){
    this._connection.query('select * from conta', callback);
}

ContasDAO.prototype.salva = function(contas,callback){
    this._connection.query('insert into conta set ?', contas,callback);
}

ContasDAO.prototype.listaCat = function(callback){
    this._connection.query('select * from categoria', callback);
}
    module.exports = function(){
    return ContasDAO;
   
}