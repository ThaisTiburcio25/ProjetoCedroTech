//seta configuracao
var app = require('./config/express')();
    console.log("servidor rodando");

//sobe o servidor
app.listen(3000,function(){
});
