module.exports = function(app){ //Define das rotas - chamada de paginas
    app.get('/contas',function(req,res,next){
    var connection = app.infra.connectionFactory(); //abre conexao
    var contasDAO =  new app.infra.ContasDAO(connection);
    var categoriasDAO = new app.infra.CategoriasDAO(connection);

    contasDAO.lista(function(erros,resultados){
        if(erros){
            return next(erros); 
        }
        res.format({
            html: function(){
                res.render('contas/lista',{lista:resultados});
            },
            json: function(){
                res.json(resultados);
            }
        });
    });

        connection.end(); //fecha conexao

        
    // categoriasDAO.lista(function(erros,resultados){
//         if(erros){
//             return next(erros); 
//         }
//         res.format({
//             html: function(){
//                 res.render('contas/form',{lista:resultados});
   
//             },
//             json: function(){
//                 res.json(resultados);
//             }
//         });
//     });

//     connection.end(); //fecha conexao
 });

    app.get('/contas/form', function(req,res){
        res.render('contas/form',
            {errosValidacao:{},contas:{}});  
});

app.post('/contas',function(req,res){
    
    var contas = req.body;
    
   req.assert('descricao','Descricao é obrigatoria').notEmpty();
   req.assert('valor','Formato invalido').isFloat();

   var erros = req.validationErrors();
   if(erros){
       res.format({
            html: function(){
                 res.status(400).render('contas/form',{errosValidacao:erros,contas:contas});
            },
            json: function(){
                res.status(400).json(erros);
            }
        });   
        return;
   }

    var connection = app.infra.connectionFactory(); //abre conexao
    var contasDAO =  new app.infra.ContasDAO(connection);
    contasDAO.salva(contas, function(erros,resultados){
       console.log(erros);
        res.redirect('/contas');
        });
});
}

// app.get('contas/remove',function(){
//     var connection = app.infra.connectionFactory();
//     var contasBanco = app.infra.contasBanco(connection);
//     var contas = contasBanco.carrega(id,callback);

//     if(contas){
//         contasBanco.remove(contas,callback);
//     }
// })